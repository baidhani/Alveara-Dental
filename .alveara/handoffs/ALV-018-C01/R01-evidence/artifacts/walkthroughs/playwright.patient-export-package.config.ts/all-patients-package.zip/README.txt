ALVEARA DENTAL - PATIENT DATA PACKAGE
Export id: 19ad1367-80bd-40b5-aaa3-4ff7af1c2018

This ZIP file is a copy of the records of every patient taken out of Alveara Dental. It holds personal health
information. Keep it where only people allowed to see these records can reach it, and delete it
when it is no longer needed.

WHAT IS IN IT
  manifest.json     What the package holds, what it leaves out and why, how many rows of each table,
                    a SHA-256 hash of every file, and anything that could not be included.
                    Read this first. If "result" is "Partial", the "problems" list says what is missing.
  data/<domain>.json  One file per part of the record (registration, appointments, billing, ...).
                    Each holds the rows of its tables exactly as the system stores them.
  readable-records/<patient folder>.html  One page per patient as a person reads it: open it in a web browser, or print it.
                    It lists the documents; the data files are the complete machine-readable copy.
  documents/<patient folder>/<document id>/<file>
                    The patients' document files (scans, images, letters), when the export included them.
                    This package includes them.
                    Patient folders are named by the patient's id;
                    manifest.json gives the folder of every patient, so no one has to read it from the name.
  README.txt        This file.

WHAT IS NOT IN IT
  The manifest lists every part of the system that is deliberately left out (sign-in accounts,
  security settings, the audit log, practice settings, technical bookkeeping) and the reason.

HOW THE DATA WAS READ
  All tables were read from one database snapshot, so the data is consistent as of one moment.

CHECKING IT
  Each file's SHA-256 hash is in manifest.json. A file whose hash differs has been changed or damaged.
  For every document, manifest.json gives the hash recorded when it was imported and the hash found
  at export, and a status: Included, HashMismatch (the file differs from what was imported; it is
  included as found, do not rely on it), Missing, Unreadable or NotIncluded.

This package is in Alveara's own layout (format alveara.patient-data-package, version 1).
It cannot yet be imported back into Alveara. A standard-format (FHIR) copy is not included.