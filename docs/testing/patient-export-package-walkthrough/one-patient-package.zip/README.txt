ALVEARA DENTAL - PATIENT DATA PACKAGE
Export id: 344bd845-50e3-48b9-a83f-3c3e5343a840

This ZIP file is a copy of a patient's record taken out of Alveara Dental. It holds personal health
information. Keep it where only people allowed to see these records can reach it, and delete it
when it is no longer needed.

WHAT IS IN IT
  manifest.json     What the package holds, what it leaves out and why, how many rows of each table,
                    a SHA-256 hash of every file, and anything that could not be included.
                    Read this first. If "result" is "Partial", the "problems" list says what is missing.
  data/<domain>.json  One file per part of the record (registration, appointments, billing, ...).
                    Each holds the rows of its tables exactly as the system stores them.
  readable-record.html  The patient's record as a person reads it: open it in a web browser, or print it.
                    It lists the documents; the data files are the complete machine-readable copy.
  documents/<patient folder>/<document id>/<file>
                    The patients' document files (scans, images, letters), when the export included them.
                    This package includes them.
                    Patient folders are named by the patient's id;
                    manifest.json gives the folder of every patient, so no one has to read it from the name.
  README.txt        This file.

WHAT IS NOT IN IT
  The manifest lists every part of the system that is deliberately left out (sign-in accounts,
  security settings, the audit log, practice settings, technical bookkeeping) and the reason.

HOW THE DATA WAS READ
  The tables were read one after another. A change made while the export ran can show in some tables and not in others; manifest.json gives the time the export started.

CHECKING IT
  Each file's SHA-256 hash is in manifest.json. A file whose hash differs has been changed or damaged.
  For every document, manifest.json gives the hash recorded when it was imported and the hash found
  at export, and a status: Included, HashMismatch (the file differs from what was imported; it is
  included as found, do not rely on it), Missing, Unreadable or NotIncluded.

This package is in Alveara's own layout (format alveara.patient-data-package, version 1).
It cannot yet be imported back into Alveara. A standard-format (FHIR) copy is not included.